import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Routes, Route } from 'react-router-dom';




import Homepage from './homepage';
import Login from './login';
import Registration from './registration';
import StudentProfile from './StudentProfile'
import Dashboard from './dashboard'


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Registration />} />
        <Route path="/student_profile" element={<StudentProfile />} />
        <Route path="/dashboard" element={<Dashboard />} />
      </Routes>
    
    </BrowserRouter>
  );
}
ReactDOM.render(<App />, document.getElementById('root'));
