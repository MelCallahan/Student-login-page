import React from 'react';
import './registration.css';
import { Link } from 'react-router-dom';

function Registration() {
  return (
    <div className="wrapper">
      <form action="">
        <h2>Student Registration</h2>
        <div className="input-box">
          
          <input type="text" required />
          <label>Student First Name</label>
        </div>
        <div className="input-box">
         
          <input type="text" required />
          <label>Student Last Name</label>
        </div>
        <div className="input-box">
          
          <input type="text" required />
          <label>Student ID</label>
        </div>
        <div className="input-box">
         
          <input type="email" required />
          <label>Email</label>
        </div>
        <div className="input-box">
          
          <input type="password" required />
          <label>Password</label>
        </div>

        <div className="study-type">
          <p className="study-type-label">Study Type:</p>
          <select className="study-type-select">
            <option value="">Select study type</option>
            <option value="Undergraduate">Undergraduate</option>
            <option value="postgraduate">Postgraduate</option>
            <option value="Doctorate">Doctorate</option>
            <option value="Masters">Masters</option>
          </select>
        </div>

        <div className="register-link">
          <p>
            <button type="submit">Submit</button>
          </p>
        </div>
        <p className="account-text">
          Already have an account? <Link to="/login">Login</Link>
        </p>
        <p>
          <Link to="/" className="homepage-button">Back to Homepage</Link>
        </p>
      </form>
    </div>
  );
}

export default Registration;
