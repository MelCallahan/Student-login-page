import React from 'react';
import './login.css';
import { Link } from 'react-router-dom';

function Login() {
  return (
    <div className="login">
      <div className="login-box">
        <h1>UNIVERSITY OF GHANA </h1>
        <h1>SCHOOL OF ENGINEERING SCIENCES</h1>
        <label>STUDENT ID</label>
        <input type="text" name="" required />
        <p>
          <label>STUDENT PIN </label>
          <input type="password" name="" required />
        </p>
        <p>
          <button className="login-button">Login</button>
        </p>
        <div className="register-link">
          <h5>
            Don't have an account? <Link to="/register" className="register">Register Here!</Link>
          </h5>
        </div>
        <button className="homepage-button">
          <Link to="/">Back to Homepage</Link>
        </button>
      </div>
    </div>
  );
}

export default Login;
