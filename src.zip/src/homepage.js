import React from 'react';
import { Link } from 'react-router-dom';
import './homepage.css';
import logo from './UG.png';

function Homepage() {
  return (
    <div className="homepage">
      <div className="container">
        <img src={logo} alt="Logo" className="logo" />
        <h1 className="university-title">UNIVERSITY OF GHANA</h1>
        <h1 className="welcome-title">Welcome to the School of Engineering Sciences!</h1>

        <p>
          Welcome to the School of Engineering Sciences at the University of Ghana. We are dedicated to providing exceptional education and research opportunities in various engineering disciplines.
        </p>
        <p>
          Our school offers a wide range of programs and specializations that cater to diverse interests and aspirations. Whether you are interested in mechanical engineering, computer science, electrical engineering, or any other field, we have the resources and expertise to support your academic journey.
        </p>
        <p>
          At the School of Engineering Sciences, we prioritize practical learning experiences. Through hands-on projects, internships, and industry collaborations, we ensure that our students develop the skills and knowledge necessary to excel in their chosen fields. Our experienced faculty members are committed to your growth and success, providing mentorship and guidance throughout your academic career.
        </p>
        <p>
          In addition to academic excellence, we also emphasize holistic development and the formation of lifelong connections. Our school organizes various extracurricular activities, clubs, and events that provide opportunities to network, explore new interests, and build lasting friendships. We encourage you to engage in these activities and make the most of your time at the School of Engineering Sciences.
        </p>

        <div className="buttons">
          <Link to="/register" className="button">Register</Link>
          <Link to="/login" className="button">Login</Link>
          <Link to="/student_profile" className="button">Student Profile</Link>
        </div>
      </div>
    </div>
  );
}

export default Homepage;
