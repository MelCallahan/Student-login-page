import './dashboard.css';
import logo from './UG.png'; 
import { Link } from 'react-router-dom';

function Dashboard() {
  return (
    <div class="wrapper">
    <form action=""></form>
    <div className="dashboard">
      <div className="dashboard-box">
        <img src={logo} alt="Logo" />
        <h1>UNIVERSITY OF GHANA</h1>
        <h1>WELCOME TO SCHOOL OF ENGINEERING SCIENCES</h1>
        
        <p>
        You may access numerous features and information from this page.
        </p>

        <Link to='/student_profile'>
        <button>View Profile</button>
        </Link>
      
        <Link to='/'>
        <button>Logout</button>
        </Link>
      </div>

    </div>
    </div>
  );
}

export default Dashboard;
