import React from 'react';
import './App.css';
import { Routes, Route } from 'react-router-dom';
import homepage from './homepage';
import login from './login';
import registration from './registration';
import './homepage.css';
import './login.css';
import './registration.css';



function App() {
  return (
    <div>
    <Routes>

      <Routes path="/" element={<homepage />} />
      <Routes path="/login" element={<login/>} />
      <Routes path="/register" element={<registration />} />
    </Routes>

  </div>
   
    
  );
}


        export default App;